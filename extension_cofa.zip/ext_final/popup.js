const BACKEND = 'https://farmacia-merlo-backend-production-69d3.up.railway.app';
const MESES = ['','Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];

function setStatus(msg, type) {
  const el = document.getElementById('status');
  el.textContent = msg;
  el.className = 'status ' + type;
}

function setProgress(pct) {
  document.getElementById('progress-wrap').style.display = pct > 0 ? 'block' : 'none';
  document.getElementById('progress-bar').style.width = pct + '%';
}

function formatPeriodo(periodo) {
  if (!periodo) return 'No detectado';
  const [anio, mes, q] = periodo.split('|');
  return (q === '1' ? '1ra' : '2da') + ' quincena ' + MESES[parseInt(mes)] + ' ' + anio;
}

async function descargarImagenBase64(url, tabId) {
  // Usar XMLHttpRequest desde el tab de COFA (tiene las cookies y evita restricciones de http://)
  const results = await chrome.scripting.executeScript({
    target: { tabId },
    func: (url) => {
      return new Promise((resolve) => {
        const xhr = new XMLHttpRequest();
        xhr.open('GET', url, true);
        xhr.withCredentials = true;
        xhr.responseType = 'blob';
        xhr.onload = function() {
          if (xhr.status === 200) {
            const reader = new FileReader();
            reader.onload = () => resolve({ data: reader.result });
            reader.readAsDataURL(xhr.response);
          } else {
            resolve({ error: 'status ' + xhr.status });
          }
        };
        xhr.onerror = () => resolve({ error: 'XHR network error' });
        xhr.send();
      });
    },
    args: [url]
  });
  const r = results[0].result;
  if (r && r.data) return r.data;
  if (r && r.error) throw new Error(r.error);
  return null;
}


function construirUrlImagen(nombreArchivo, sufijo) {
  // Normalizar nombre: si empieza con 0 seguido de 25x, agregar el 2
  let nombre = nombreArchivo;
  if (/^0(25|24|23|26)/.test(nombre)) nombre = '2' + nombre;
  const anio = nombre.slice(0, 4);  // "2025"
  const mes  = nombre.slice(4, 6);  // "02"
  const dia  = parseInt(nombre.slice(6, 8)); // 3
  const aa   = anio.slice(2); // "25"
  const q    = dia <= 15 ? '1' : '2';
  const codigo = aa + mes + q; // "25021"
  const carpeta = '297_col._bs.as._colegio_de_azul';
  const farmacia = '930200835';
  return 'https://ncr.cofa.org.ar/ajustes/' + codigo + '/' + carpeta + '/' + farmacia + '_' + nombre + '_' + sufijo + '.png';
}


const _logs = [];
function log(msg) {
  _logs.push(new Date().toISOString().slice(11,19) + ' ' + msg);
  setStatus(msg.slice(0, 80), msg.includes('Error') || msg.includes('FALLO') ? 'error' : 'info');
}

function descargarLogs() {
  const blob = new Blob([_logs.join('\n')], { type: 'text/plain' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'debug_cofa.txt';
  a.click();
}

async function analizar() {
  const btn = document.getElementById('btn-analizar');
  btn.disabled = true;
  btn.textContent = 'Analizando...';
  setProgress(5);

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    if (!tab.url.includes('ncr.cofa.org.ar/tablero/resumen')) {
      document.getElementById('warning-url').style.display = 'block';
      setStatus('Navegá al tablero de COFA primero.', 'error');
      btn.disabled = false;
      btn.textContent = 'Analizar débitos →';
      setProgress(0);
      return;
    }

    // Leer período
    const periodoResult = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => { const sel = document.querySelector('select'); return sel ? sel.value : null; }
    });
    const periodo = periodoResult[0].result;

    document.getElementById('warning-url').style.display = 'none';
    setStatus('Buscando ajustes...', 'info');
    setProgress(10);

    // Leer ajustes y monto
    const resumen = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        const ajusteLinks = [];
        let montoTotal = 0;
        document.querySelectorAll('u').forEach(u => {
          if (/^\dQ\d{4}$/.test(u.textContent.trim())) ajusteLinks.push(u.textContent.trim());
        });
        document.querySelectorAll('tr').forEach(row => {
          const txt = row.textContent.toUpperCase();
          if (txt.includes('AJUSTE') && txt.includes('DEBITO')) {
            const nums = [];
            row.querySelectorAll('td').forEach(td => {
              const num = parseFloat(td.textContent.trim().replace(/\./g,'').replace(',','.'));
              if (!isNaN(num) && num > 100) nums.push(num);
            });
            // El monto del débito es el número más chico mayor a 100
            if (nums.length > 0) montoTotal = Math.min(...nums);
          }
        });
        return { ajusteLinks, montoTotal };
      }
    });

    const { ajusteLinks, montoTotal } = resumen[0].result;

    if (ajusteLinks.length === 0) {
      setStatus('No se encontraron débitos para este período.', 'error');
      btn.disabled = false;
      btn.textContent = 'Analizar débitos →';
      setProgress(0);
      return;
    }

    const ajustes = [];
    let recetasTotales = 0;

    for (let i = 0; i < ajusteLinks.length; i++) {
      const linkId = ajusteLinks[i];
      setProgress(15 + Math.round(i / ajusteLinks.length * 40));
      setStatus('Cargando ajuste ' + linkId + '...', 'info');

      // Click en el link del ajuste
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: (linkId) => {
          const el = Array.from(document.querySelectorAll('u')).find(u => u.textContent.trim() === linkId);
          if (el) el.click();
        },
        args: [linkId]
      });

      await new Promise(r => setTimeout(r, 3000));

      // Leer el iframe con allFrames
      let archivos = [];
      try {
        const allFrames = await chrome.scripting.executeScript({
          target: { tabId: tab.id, allFrames: true },
          func: () => {
            const url = window.location.href;
            if (!url.includes('ajuste') && !url.includes('Ajuste') && !url.includes('p=20')) return null;
            const archivos = [];
            document.querySelectorAll('tr').forEach(row => {
              const cells = row.querySelectorAll('td');
              if (cells.length < 3) return;
              // Buscar celda con .png
              let nombreIdx = -1;
              for (let i = 0; i < cells.length; i++) {
                if (cells[i].textContent.trim().endsWith('.png')) { nombreIdx = i; break; }
              }
              if (nombreIdx === -1) return;
              const nombre = cells[nombreIdx].textContent.trim();
              const nota = cells[cells.length - 1].textContent.trim();
              // Capturar URL real del enlace del ícono
              const linkEl = row.querySelector('a[href*=".png"]') || row.querySelector('a');
              const imgUrl = linkEl ? linkEl.href : '';
              const base = nombre.replace(/_00[12]\.png$/i, '');
              if (!base) return;
              let entry = archivos.find(a => a.nombre === base);
              if (!entry) {
                entry = { nombre: base, nota, img_url_001: '', img_url_002: '' };
                archivos.push(entry);
              }
              if (nombre.endsWith('_001.png') && imgUrl) entry.img_url_001 = imgUrl;
              else if (nombre.endsWith('_002.png') && imgUrl) entry.img_url_002 = imgUrl;
            });
            return { archivos };
          }
        });

        for (const frame of allFrames) {
          if (frame.result && frame.result.archivos && frame.result.archivos.length > 0) {
            archivos = frame.result.archivos;
            break;
          }
        }
      } catch(e) {}

      // Descargar imágenes para cada receta
      setStatus('Descargando imágenes del ajuste ' + linkId + ' (' + archivos.length + ' recetas)...', 'info');
      
      for (let j = 0; j < archivos.length; j++) {
        const arch = archivos[j];
        recetasTotales++;
        
        // Construir URLs con el patrón real de COFA
        arch.img_url_001 = construirUrlImagen(arch.nombre, '001');
        arch.img_url_002 = construirUrlImagen(arch.nombre, '002');

        // Descargar ambas imágenes con logs visibles
        try {
          log('Descargando img ' + (j+1) + '/' + archivos.length + ' URL: ' + arch.img_url_001);
          arch.img_001 = await descargarImagenBase64(arch.img_url_001, tab.id);
          log('Img1: ' + (arch.img_001 ? 'OK ' + Math.round(arch.img_001.length/1024) + 'KB' : 'FALLO'));
          await new Promise(r => setTimeout(r, 500));
        } catch(e) { 
          arch.img_001 = null; 
          log('ERROR img_001: ' + e.message);
          await new Promise(r => setTimeout(r, 500));
        }
        try {
          arch.img_002 = await descargarImagenBase64(arch.img_url_002, tab.id);
          log('Img2: ' + (arch.img_002 ? 'OK ' + Math.round(arch.img_002.length/1024) + 'KB' : 'FALLO'));
          await new Promise(r => setTimeout(r, 500));
        } catch(e) { 
          arch.img_002 = null;
          log('ERROR img_002: ' + e.message);
          await new Promise(r => setTimeout(r, 500));
        }

        setProgress(15 + Math.round((i + (j+1)/archivos.length) / ajusteLinks.length * 40));
      }

      ajustes.push({
        id: linkId,
        monto: Math.round(montoTotal / ajusteLinks.length * 100) / 100,
        archivos
      });
    }

    setProgress(60);
    setStatus('Analizando ' + recetasTotales + ' recetas con IA... (puede tardar unos minutos)', 'info');

    // Mandar al backend para análisis
    const payload = { periodo, ajustes, farmacia_id: '930200835' };
    
    const iaResp = await fetch(BACKEND + '/debitos/analizar', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const iaData = await iaResp.json();

    setProgress(90);
    setStatus('Guardando resultado...', 'info');

    // Guardar en el backend cache
    const savePayload = { ...iaData, total_monto: montoTotal, periodo, farmacia_id: '930200835' };
    await fetch(BACKEND + '/debitos/guardar', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(savePayload)
    });

    setProgress(100);
    setStatus('✓ ' + recetasTotales + ' recetas — descargando logs y abriendo app...', 'success');
    descargarLogs();

    // Esperar 3 segundos para que se descargue el archivo antes de abrir la nueva pestaña
    setTimeout(() => {
      chrome.tabs.create({ url: 'https://reporte-ooss.netlify.app/?debitos=1#debitos' });
    }, 3000);

  } catch(e) {
    log('ERROR FATAL: ' + e.message);
    descargarLogs();
    btn.disabled = false;
    btn.textContent = 'Analizar débitos →';
    setProgress(0);
  }
}

document.addEventListener('DOMContentLoaded', function() {
  document.getElementById('btn-analizar').addEventListener('click', analizar);
  chrome.tabs.query({ active: true, currentWindow: true }, async ([tab]) => {
    if (!tab || !tab.url.includes('ncr.cofa.org.ar/tablero/resumen')) {
      document.getElementById('warning-url').style.display = 'block';
      document.getElementById('periodo-info').style.display = 'none';
      return;
    }
    try {
      const result = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => { const sel = document.querySelector('select'); return sel ? sel.value : null; }
      });
      const periodo = result[0].result;
      if (periodo) document.getElementById('periodo-texto').textContent = formatPeriodo(periodo);
    } catch(e) {}
  });
});
