// content.js — corre en ncr.cofa.org.ar/tablero/resumen/
// Lee los datos de la página y los manda al backend

const BACKEND = 'https://farmacia-merlo-backend-production-69d3.up.railway.app';

function parsearAjustesDelDOM() {
  const ajusteLinks = [];
  let montoTotal = 0;

  // Buscar todos los elementos <u> con formato NQ####
  document.querySelectorAll('u').forEach(u => {
    const txt = u.textContent.trim();
    if (/^\dQ\d{4}$/.test(txt)) {
      ajusteLinks.push(txt);
    }
  });

  // Buscar monto en la fila AJUSTE/DEBITO
  document.querySelectorAll('tr').forEach(row => {
    const txt = row.textContent.toUpperCase();
    if (txt.includes('AJUSTE') && txt.includes('DEBITO')) {
      row.querySelectorAll('td').forEach(td => {
        const num = parseFloat(td.textContent.trim().replace(/\./g, '').replace(',', '.'));
        if (!isNaN(num) && num > montoTotal) montoTotal = num;
      });
    }
  });

  return { ajusteLinks, montoTotal };
}

function parsearArchivosDelIframe(iframeDoc) {
  const archivos = [];
  iframeDoc.querySelectorAll('tr').forEach(row => {
    const cells = row.querySelectorAll('td');
    if (cells.length < 4) return;
    const nombre = cells[1]?.textContent?.trim() || '';
    const nota = cells[3]?.textContent?.trim() || '';
    if (!nombre.endsWith('.png')) return;
    const base = nombre.replace(/_00[12]\.png$/, '');
    if (base && !archivos.find(a => a.nombre === base)) {
      archivos.push({ nombre: base, nota });
    }
  });
  return archivos;
}

async function clickAjusteYLeerIframe(linkId) {
  // Click en el link del ajuste
  const links = Array.from(document.querySelectorAll('u'));
  const link = links.find(u => u.textContent.trim() === linkId);
  if (link) link.click();

  // Esperar que el iframe cargue
  await new Promise(r => setTimeout(r, 2000));

  // Leer el iframe
  const iframe = document.querySelector('iframe[name="frameC"]');
  if (!iframe) return [];

  try {
    const iDoc = iframe.contentDocument || iframe.contentWindow.document;
    return parsearArchivosDelIframe(iDoc);
  } catch(e) {
    return [];
  }
}

// Exponer función al popup
window.__cofaScrape = async function(periodo) {
  const { ajusteLinks, montoTotal } = parsearAjustesDelDOM();

  if (ajusteLinks.length === 0) {
    return { error: 'No se encontraron débitos en esta página. Asegurate de haber seleccionado el período correcto.' };
  }

  const ajustes = [];
  for (const linkId of ajusteLinks) {
    const archivos = await clickAjusteYLeerIframe(linkId);
    ajustes.push({
      id: linkId,
      monto: Math.round(montoTotal / ajusteLinks.length * 100) / 100,
      archivos
    });
  }

  const total_recetas = ajustes.reduce((s, a) => s + a.archivos.length, 0);
  return { periodo, ajustes, total_recetas, total_monto: montoTotal };
};

// Notificar al popup que el content script está listo
chrome.runtime.sendMessage({ tipo: 'CONTENT_LISTO', url: window.location.href });
