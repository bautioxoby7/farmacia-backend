const BACKEND = 'https://farmacia-merlo-backend-production-69d3.up.railway.app';

function setStatus(msg, type) {
  const el = document.getElementById('status');
  el.textContent = msg;
  el.className = 'status ' + type;
}

function setProgress(pct) {
  document.getElementById('progress-wrap').style.display = pct > 0 ? 'block' : 'none';
  document.getElementById('progress-bar').style.width = pct + '%';
}

async function analizar() {
  const btn = document.getElementById('btn-analizar');
  btn.disabled = true;
  btn.textContent = 'Analizando...';
  setProgress(10);

  const anio = document.getElementById('anio').value;
  const mes = document.getElementById('mes').value;
  const q = document.getElementById('quincena').value;
  const periodo = anio + '|' + mes + '|' + q;

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    if (!tab.url.includes('ncr.cofa.org.ar/tablero/resumen')) {
      document.getElementById('warning-url').style.display = 'block';
      setStatus('Navegá al tablero de COFA primero.', 'error');
      btn.disabled = false;
      btn.textContent = 'Analizar débitos →';
      setProgress(0);
      return;
    }

    document.getElementById('warning-url').style.display = 'none';
    setStatus('Leyendo datos del tablero...', 'info');
    setProgress(25);

    // Seleccionar el período
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: (periodo) => {
        const sel = document.querySelector('select');
        if (sel) {
          sel.value = periodo;
          sel.dispatchEvent(new Event('change', { bubbles: true }));
        }
      },
      args: [periodo]
    });

    await new Promise(r => setTimeout(r, 2000));
    setProgress(40);

    // Scraping
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: async () => {
        const ajusteLinks = [];
        let montoTotal = 0;

        document.querySelectorAll('u').forEach(u => {
          if (/^\dQ\d{4}$/.test(u.textContent.trim())) {
            ajusteLinks.push(u.textContent.trim());
          }
        });

        document.querySelectorAll('tr').forEach(row => {
          const txt = row.textContent.toUpperCase();
          if (txt.includes('AJUSTE') && txt.includes('DEBITO')) {
            row.querySelectorAll('td').forEach(td => {
              const num = parseFloat(td.textContent.trim().replace(/\./g,'').replace(',','.'));
              if (!isNaN(num) && num > montoTotal) montoTotal = num;
            });
          }
        });

        if (ajusteLinks.length === 0) {
          return { error: 'No se encontraron débitos para este período.' };
        }

        const ajustes = [];
        for (const linkId of ajusteLinks) {
          const link = Array.from(document.querySelectorAll('u')).find(u => u.textContent.trim() === linkId);
          if (link) link.click();
          await new Promise(r => setTimeout(r, 2000));

          const iframe = document.querySelector('iframe[name="frameC"]');
          const archivos = [];
          if (iframe) {
            try {
              const iDoc = iframe.contentDocument || iframe.contentWindow.document;
              iDoc.querySelectorAll('tr').forEach(row => {
                const cells = row.querySelectorAll('td');
                if (cells.length < 4) return;
                const nombre = cells[1]?.textContent?.trim() || '';
                const nota = cells[3]?.textContent?.trim() || '';
                if (!nombre.endsWith('.png')) return;
                const base = nombre.replace(/_00[12]\.png$/, '');
                if (base && !archivos.find(a => a.nombre === base)) {
                  archivos.push({ nombre: base, nota });
                }
              });
            } catch(e) {}
          }

          ajustes.push({
            id: linkId,
            monto: Math.round(montoTotal / ajusteLinks.length * 100) / 100,
            archivos
          });
        }

        return {
          ajustes,
          total_recetas: ajustes.reduce((s,a) => s + a.archivos.length, 0),
          total_monto: montoTotal
        };
      }
    });

    const scraped = results[0].result;
    setProgress(70);

    if (scraped.error) {
      setStatus(scraped.error, 'error');
      btn.disabled = false;
      btn.textContent = 'Analizar débitos →';
      setProgress(0);
      return;
    }

    setStatus('Generando análisis con IA...', 'info');
    setProgress(85);

    const iaResp = await fetch(BACKEND + '/debitos/analizar', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ periodo, ajustes: scraped.ajustes })
    });
    const iaData = await iaResp.json();

    setProgress(100);
    setStatus('✓ Análisis completo — ' + scraped.total_recetas + ' recetas procesadas', 'success');

    await chrome.storage.local.set({ ultimoAnalisis: { ...iaData, total_monto: scraped.total_monto } });

    setTimeout(() => {
      chrome.tabs.create({ url: 'https://reporte-ooss.netlify.app/#debitos' });
    }, 1000);

  } catch(e) {
    setStatus('Error: ' + e.message, 'error');
    btn.disabled = false;
    btn.textContent = 'Analizar débitos →';
    setProgress(0);
  }
}

// Inicializar cuando carga el popup
document.addEventListener('DOMContentLoaded', function() {
  document.getElementById('btn-analizar').addEventListener('click', analizar);

  chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
    if (!tab.url.includes('ncr.cofa.org.ar/tablero/resumen')) {
      document.getElementById('warning-url').style.display = 'block';
    }
  });
});
