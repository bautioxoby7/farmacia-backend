// Corre en ncr.cofa.org.ar incluyendo el iframe de Ajustes
// Expone los datos del iframe al popup via mensajes

chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {
  if (msg.tipo === 'LEER_AJUSTES_IFRAME') {
    const archivos = [];
    document.querySelectorAll('tr').forEach(row => {
      const cells = row.querySelectorAll('td');
      if (cells.length < 4) return;
      const nombre = cells[1]?.textContent?.trim() || '';
      const nota = cells[3]?.textContent?.trim() || '';
      if (!nombre.endsWith('.png')) return;
      const base = nombre.replace(/_00[12]\.png$/, '');
      if (base && !archivos.find(a => a.nombre === base)) {
        archivos.push({ nombre: base, nota });
      }
    });
    sendResponse({ archivos });
  }
  return true;
});
