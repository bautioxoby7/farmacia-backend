const BACKEND = 'https://farmacia-merlo-backend-production-69d3.up.railway.app';
const MESES = ['','Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];

function setStatus(msg, type) {
  const el = document.getElementById('status');
  el.textContent = msg;
  el.className = 'status ' + type;
}

function setProgress(pct) {
  document.getElementById('progress-wrap').style.display = pct > 0 ? 'block' : 'none';
  document.getElementById('progress-bar').style.width = pct + '%';
}

function formatPeriodo(periodo) {
  if (!periodo) return 'No detectado';
  const [anio, mes, q] = periodo.split('|');
  return (q === '1' ? '1ra' : '2da') + ' quincena ' + MESES[parseInt(mes)] + ' ' + anio;
}

async function descargarImagenBase64(url, tabId) {
  // Descargar la imagen desde COFA usando la sesión activa del browser
  const results = await chrome.scripting.executeScript({
    target: { tabId },
    func: async (url) => {
      try {
        const resp = await fetch(url, { credentials: 'include' });
        if (!resp.ok) return null;
        const blob = await resp.blob();
        return await new Promise(resolve => {
          const reader = new FileReader();
          reader.onload = () => resolve(reader.result);
          reader.readAsDataURL(blob);
        });
      } catch(e) { return null; }
    },
    args: [url]
  });
  return results[0].result;
}

async function analizar() {
  const btn = document.getElementById('btn-analizar');
  btn.disabled = true;
  btn.textContent = 'Analizando...';
  setProgress(5);

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    if (!tab.url.includes('ncr.cofa.org.ar/tablero/resumen')) {
      document.getElementById('warning-url').style.display = 'block';
      setStatus('Navegá al tablero de COFA primero.', 'error');
      btn.disabled = false;
      btn.textContent = 'Analizar débitos →';
      setProgress(0);
      return;
    }

    // Leer período
    const periodoResult = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => { const sel = document.querySelector('select'); return sel ? sel.value : null; }
    });
    const periodo = periodoResult[0].result;

    document.getElementById('warning-url').style.display = 'none';
    setStatus('Buscando ajustes...', 'info');
    setProgress(10);

    // Leer ajustes y monto
    const resumen = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        const ajusteLinks = [];
        let montoTotal = 0;
        document.querySelectorAll('u').forEach(u => {
          if (/^\dQ\d{4}$/.test(u.textContent.trim())) ajusteLinks.push(u.textContent.trim());
        });
        document.querySelectorAll('tr').forEach(row => {
          const txt = row.textContent.toUpperCase();
          if (txt.includes('AJUSTE') && txt.includes('DEBITO')) {
            const nums = [];
            row.querySelectorAll('td').forEach(td => {
              const num = parseFloat(td.textContent.trim().replace(/\./g,'').replace(',','.'));
              if (!isNaN(num) && num > 0) nums.push(num);
            });
            if (nums.length > 0) montoTotal = Math.min(...nums);
          }
        });
        return { ajusteLinks, montoTotal };
      }
    });

    const { ajusteLinks, montoTotal } = resumen[0].result;

    if (ajusteLinks.length === 0) {
      setStatus('No se encontraron débitos para este período.', 'error');
      btn.disabled = false;
      btn.textContent = 'Analizar débitos →';
      setProgress(0);
      return;
    }

    const ajustes = [];
    let recetasTotales = 0;

    for (let i = 0; i < ajusteLinks.length; i++) {
      const linkId = ajusteLinks[i];
      setProgress(15 + Math.round(i / ajusteLinks.length * 40));
      setStatus('Cargando ajuste ' + linkId + '...', 'info');

      // Click en el link del ajuste
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: (linkId) => {
          const el = Array.from(document.querySelectorAll('u')).find(u => u.textContent.trim() === linkId);
          if (el) el.click();
        },
        args: [linkId]
      });

      await new Promise(r => setTimeout(r, 3000));

      // Leer el iframe con allFrames
      let archivos = [];
      try {
        const allFrames = await chrome.scripting.executeScript({
          target: { tabId: tab.id, allFrames: true },
          func: () => {
            const url = window.location.href;
            if (!url.includes('ajuste') && !url.includes('Ajuste') && !url.includes('p=20')) return null;
            const archivos = [];
            document.querySelectorAll('tr').forEach(row => {
              const cells = row.querySelectorAll('td');
              if (cells.length < 3) return;
              let nombreIdx = -1;
              for (let i = 0; i < cells.length; i++) {
                if (cells[i].textContent.trim().endsWith('.png')) { nombreIdx = i; break; }
              }
              if (nombreIdx === -1) return;
              const nombre = cells[nombreIdx].textContent.trim();
              const nota = cells[cells.length - 1].textContent.trim();
              // URL de la imagen: buscar en el link del ícono
              let imgUrl = '';
              const linkEl = cells[0].querySelector('a') || row.querySelector('a');
              if (linkEl) imgUrl = linkEl.href;
              const base = nombre.replace(/_00[12]\.png$/i, '');
              if (base && !archivos.find(a => a.nombre === base)) {
                archivos.push({ nombre: base, nota, img_url_001: '', img_url_002: '' });
              } else if (base) {
                // Segunda imagen del mismo archivo base
                const existing = archivos.find(a => a.nombre === base);
                if (existing && !existing.img_url_002 && imgUrl) existing.img_url_002 = imgUrl;
              }
              // Asignar URL de imagen
              const entry = archivos.find(a => a.nombre === base);
              if (entry && imgUrl) {
                if (nombre.endsWith('_001.png')) entry.img_url_001 = imgUrl;
                else if (nombre.endsWith('_002.png')) entry.img_url_002 = imgUrl;
              }
            });
            return { archivos, baseUrl: window.location.origin + window.location.pathname };
          }
        });

        for (const frame of allFrames) {
          if (frame.result && frame.result.archivos && frame.result.archivos.length > 0) {
            archivos = frame.result.archivos;
            break;
          }
        }
      } catch(e) {}

      // Descargar imágenes para cada receta
      setStatus('Descargando imágenes del ajuste ' + linkId + ' (' + archivos.length + ' recetas)...', 'info');
      
      for (let j = 0; j < archivos.length; j++) {
        const arch = archivos[j];
        recetasTotales++;
        
        // Construir URLs de las imágenes si no las tenemos
        // URL base del iframe para construir las URLs de imagen
        const baseImgUrl = 'https://ncr.cofa.org.ar/tablero/resumen/Ajustes/';
        
        if (!arch.img_url_001) {
          arch.img_url_001 = baseImgUrl + arch.nombre + '_001.png';
        }
        if (!arch.img_url_002) {
          arch.img_url_002 = baseImgUrl + arch.nombre + '_002.png';
        }

        // Descargar ambas imágenes
        try {
          arch.img_001 = await descargarImagenBase64(arch.img_url_001, tab.id);
        } catch(e) { arch.img_001 = null; }
        try {
          arch.img_002 = await descargarImagenBase64(arch.img_url_002, tab.id);
        } catch(e) { arch.img_002 = null; }

        setProgress(15 + Math.round((i + (j+1)/archivos.length) / ajusteLinks.length * 40));
      }

      ajustes.push({
        id: linkId,
        monto: Math.round(montoTotal / ajusteLinks.length * 100) / 100,
        archivos
      });
    }

    setProgress(60);
    setStatus('Analizando ' + recetasTotales + ' recetas con IA... (puede tardar unos minutos)', 'info');

    // Mandar al backend para análisis
    const payload = { periodo, ajustes, farmacia_id: '930200835' };
    
    const iaResp = await fetch(BACKEND + '/debitos/analizar', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const iaData = await iaResp.json();

    setProgress(90);
    setStatus('Guardando resultado...', 'info');

    // Guardar en el backend cache
    const savePayload = { ...iaData, total_monto: montoTotal, periodo, farmacia_id: '930200835' };
    await fetch(BACKEND + '/debitos/guardar', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(savePayload)
    });

    setProgress(100);
    setStatus('✓ ' + recetasTotales + ' recetas analizadas — abriendo app...', 'success');

    setTimeout(() => {
      chrome.tabs.create({ url: 'https://reporte-ooss.netlify.app/?debitos=1#debitos' });
    }, 1200);

  } catch(e) {
    setStatus('Error: ' + e.message, 'error');
    btn.disabled = false;
    btn.textContent = 'Analizar débitos →';
    setProgress(0);
  }
}

document.addEventListener('DOMContentLoaded', function() {
  document.getElementById('btn-analizar').addEventListener('click', analizar);
  chrome.tabs.query({ active: true, currentWindow: true }, async ([tab]) => {
    if (!tab || !tab.url.includes('ncr.cofa.org.ar/tablero/resumen')) {
      document.getElementById('warning-url').style.display = 'block';
      document.getElementById('periodo-info').style.display = 'none';
      return;
    }
    try {
      const result = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => { const sel = document.querySelector('select'); return sel ? sel.value : null; }
      });
      const periodo = result[0].result;
      if (periodo) document.getElementById('periodo-texto').textContent = formatPeriodo(periodo);
    } catch(e) {}
  });
});
