const BACKEND = 'https://farmacia-merlo-backend-production-69d3.up.railway.app';
const MESES = ['','Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];

function setStatus(msg, type) {
  const el = document.getElementById('status');
  el.textContent = msg;
  el.className = 'status ' + type;
}

function setProgress(pct) {
  document.getElementById('progress-wrap').style.display = pct > 0 ? 'block' : 'none';
  document.getElementById('progress-bar').style.width = pct + '%';
}

function formatPeriodo(periodo) {
  if (!periodo) return 'No detectado';
  const [anio, mes, q] = periodo.split('|');
  return (q === '1' ? '1ra' : '2da') + ' quincena ' + MESES[parseInt(mes)] + ' ' + anio;
}

let periodoActual = null;

async function analizar() {
  const btn = document.getElementById('btn-analizar');
  btn.disabled = true;
  btn.textContent = 'Analizando...';
  setProgress(10);

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    if (!tab.url.includes('ncr.cofa.org.ar/tablero/resumen')) {
      document.getElementById('warning-url').style.display = 'block';
      setStatus('Navegá al tablero de COFA primero.', 'error');
      btn.disabled = false;
      btn.textContent = 'Analizar débitos →';
      setProgress(0);
      return;
    }

    // Leer el período seleccionado en la página
    const periodoResult = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        const sel = document.querySelector('select');
        return sel ? sel.value : null;
      }
    });

    const periodo = periodoResult[0].result;
    if (!periodo) {
      setStatus('No se pudo detectar el período. Seleccionalo en COFA primero.', 'error');
      btn.disabled = false;
      btn.textContent = 'Analizar débitos →';
      setProgress(0);
      return;
    }

    document.getElementById('warning-url').style.display = 'none';
    setStatus('Buscando ajustes/débitos...', 'info');
    setProgress(25);

    // Leer ajustes y monto del DOM
    const resumen = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        const ajusteLinks = [];
        let montoTotal = 0;
        document.querySelectorAll('u').forEach(u => {
          if (/^\dQ\d{4}$/.test(u.textContent.trim())) ajusteLinks.push(u.textContent.trim());
        });
        document.querySelectorAll('tr').forEach(row => {
          const txt = row.textContent.toUpperCase();
          if (txt.includes('AJUSTE') && txt.includes('DEBITO')) {
            row.querySelectorAll('td').forEach(td => {
              const num = parseFloat(td.textContent.trim().replace(/\./g,'').replace(',','.'));
              if (!isNaN(num) && num > montoTotal) montoTotal = num;
            });
          }
        });
        return { ajusteLinks, montoTotal };
      }
    });

    const { ajusteLinks, montoTotal } = resumen[0].result;

    if (ajusteLinks.length === 0) {
      setStatus('No se encontraron débitos para este período.', 'error');
      btn.disabled = false;
      btn.textContent = 'Analizar débitos →';
      setProgress(0);
      return;
    }

    setStatus('Encontrados ' + ajusteLinks.length + ' ajuste(s). Leyendo recetas...', 'info');

    const ajustes = [];
    for (let i = 0; i < ajusteLinks.length; i++) {
      const linkId = ajusteLinks[i];
      setProgress(35 + Math.round(i / ajusteLinks.length * 30));
      setStatus('Cargando ' + linkId + '...', 'info');

      // Click en el link del ajuste
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: (linkId) => {
          const el = Array.from(document.querySelectorAll('u')).find(u => u.textContent.trim() === linkId);
          if (el) el.click();
        },
        args: [linkId]
      });

      await new Promise(r => setTimeout(r, 2500));

      // Leer el iframe con all_frames
      let archivos = [];
      try {
        const allFrames = await chrome.scripting.executeScript({
          target: { tabId: tab.id, allFrames: true },
          func: () => {
            if (!window.location.href.includes('Ajuste')) return null;
            const archivos = [];
            document.querySelectorAll('tr').forEach(row => {
              const cells = row.querySelectorAll('td');
              if (cells.length < 4) return;
              const nombre = cells[1]?.textContent?.trim() || '';
              const nota = cells[3]?.textContent?.trim() || '';
              if (!nombre.endsWith('.png')) return;
              const base = nombre.replace(/_00[12]\.png$/, '');
              if (base && !archivos.find(a => a.nombre === base)) {
                archivos.push({ nombre: base, nota });
              }
            });
            return archivos;
          }
        });

        for (const frame of allFrames) {
          if (frame.result && frame.result.length > 0) {
            archivos = frame.result;
            break;
          }
        }
      } catch(e) {}

      ajustes.push({
        id: linkId,
        monto: Math.round(montoTotal / ajusteLinks.length * 100) / 100,
        archivos
      });
    }

    const total_recetas = ajustes.reduce((s,a) => s + a.archivos.length, 0);
    setProgress(75);
    setStatus('Generando análisis con IA...', 'info');

    const iaResp = await fetch(BACKEND + '/debitos/analizar', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ periodo, ajustes })
    });
    const iaData = await iaResp.json();

    setProgress(100);
    setStatus('✓ ' + total_recetas + ' recetas procesadas — abriendo app...', 'success');

    await chrome.storage.local.set({
      ultimoAnalisis: { ...iaData, total_monto: montoTotal, periodo }
    });

    setTimeout(() => {
      chrome.tabs.create({ url: 'https://reporte-ooss.netlify.app/#debitos' });
    }, 1200);

  } catch(e) {
    setStatus('Error: ' + e.message, 'error');
    btn.disabled = false;
    btn.textContent = 'Analizar débitos →';
    setProgress(0);
  }
}

document.addEventListener('DOMContentLoaded', function() {
  document.getElementById('btn-analizar').addEventListener('click', analizar);

  chrome.tabs.query({ active: true, currentWindow: true }, async ([tab]) => {
    if (!tab || !tab.url.includes('ncr.cofa.org.ar/tablero/resumen')) {
      document.getElementById('warning-url').style.display = 'block';
      document.getElementById('periodo-info').style.display = 'none';
      return;
    }

    // Detectar el período actual
    try {
      const result = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          const sel = document.querySelector('select');
          return sel ? sel.value : null;
        }
      });
      const periodo = result[0].result;
      if (periodo) {
        periodoActual = periodo;
        document.getElementById('periodo-texto').textContent = formatPeriodo(periodo);
      }
    } catch(e) {}
  });
});
