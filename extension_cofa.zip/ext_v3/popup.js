const BACKEND = 'https://farmacia-merlo-backend-production-69d3.up.railway.app';
const MESES = ['','Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];

function setStatus(msg, type) {
  const el = document.getElementById('status');
  el.textContent = msg;
  el.className = 'status ' + type;
}

function setProgress(pct) {
  document.getElementById('progress-wrap').style.display = pct > 0 ? 'block' : 'none';
  document.getElementById('progress-bar').style.width = pct + '%';
}

function formatPeriodo(periodo) {
  if (!periodo) return 'No detectado';
  const [anio, mes, q] = periodo.split('|');
  return (q === '1' ? '1ra' : '2da') + ' quincena ' + MESES[parseInt(mes)] + ' ' + anio;
}

async function analizar() {
  const btn = document.getElementById('btn-analizar');
  btn.disabled = true;
  btn.textContent = 'Analizando...';
  setProgress(10);

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    if (!tab.url.includes('ncr.cofa.org.ar/tablero/resumen')) {
      document.getElementById('warning-url').style.display = 'block';
      setStatus('Navegá al tablero de COFA primero.', 'error');
      btn.disabled = false;
      btn.textContent = 'Analizar débitos →';
      setProgress(0);
      return;
    }

    const periodoResult = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => { const sel = document.querySelector('select'); return sel ? sel.value : null; }
    });
    const periodo = periodoResult[0].result;

    document.getElementById('warning-url').style.display = 'none';
    setStatus('Buscando ajustes...', 'info');
    setProgress(25);

    const resumen = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        const ajusteLinks = [];
        let montoTotal = 0;
        document.querySelectorAll('u').forEach(u => {
          if (/^\dQ\d{4}$/.test(u.textContent.trim())) ajusteLinks.push(u.textContent.trim());
        });
        document.querySelectorAll('tr').forEach(row => {
          const txt = row.textContent.toUpperCase();
          if (txt.includes('AJUSTE') && txt.includes('DEBITO')) {
            row.querySelectorAll('td').forEach(td => {
              const num = parseFloat(td.textContent.trim().replace(/\./g,'').replace(',','.'));
              if (!isNaN(num) && num > montoTotal) montoTotal = num;
            });
          }
        });
        return { ajusteLinks, montoTotal };
      }
    });

    const { ajusteLinks, montoTotal } = resumen[0].result;

    if (ajusteLinks.length === 0) {
      setStatus('No se encontraron débitos para este período.', 'error');
      btn.disabled = false;
      btn.textContent = 'Analizar débitos →';
      setProgress(0);
      return;
    }

    const ajustes = [];
    for (let i = 0; i < ajusteLinks.length; i++) {
      const linkId = ajusteLinks[i];
      setProgress(35 + Math.round(i / ajusteLinks.length * 30));
      setStatus('Cargando ' + linkId + '...', 'info');

      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: (linkId) => {
          const el = Array.from(document.querySelectorAll('u')).find(u => u.textContent.trim() === linkId);
          if (el) el.click();
        },
        args: [linkId]
      });

      await new Promise(r => setTimeout(r, 3000));

      let archivos = [];
      try {
        const allFrames = await chrome.scripting.executeScript({
          target: { tabId: tab.id, allFrames: true },
          func: () => {
            const url = window.location.href;
            if (!url.includes('ajuste') && !url.includes('Ajuste') && !url.includes('p=20')) return null;
            
            const archivos = [];
            document.querySelectorAll('tr').forEach(row => {
              const cells = row.querySelectorAll('td');
              if (cells.length < 6) return;
              
              // Buscar en todas las celdas cual tiene el .png
              let nombreIdx = -1;
              for (let i = 0; i < cells.length; i++) {
                if (cells[i].textContent.trim().endsWith('.png')) {
                  nombreIdx = i;
                  break;
                }
              }
              if (nombreIdx === -1) return;
              
              const nombre = cells[nombreIdx].textContent.trim();
              // La nota es la última celda
              const nota = cells[cells.length - 1].textContent.trim();
              const base = nombre.replace(/_00[12]\.png$/i, '');
              if (base && !archivos.find(a => a.nombre === base)) {
                archivos.push({ nombre: base, nota });
              }
            });
            return archivos;
          }
        });

        for (const frame of allFrames) {
          if (frame.result && frame.result.length > 0) {
            archivos = frame.result;
            break;
          }
        }
      } catch(e) {}

      ajustes.push({
        id: linkId,
        monto: Math.round(montoTotal / ajusteLinks.length * 100) / 100,
        archivos
      });
    }

    const total_recetas = ajustes.reduce((s,a) => s + a.archivos.length, 0);
    setProgress(75);
    setStatus('Generando análisis con IA (' + total_recetas + ' recetas)...', 'info');

    const iaResp = await fetch(BACKEND + '/debitos/analizar', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ periodo, ajustes })
    });
    const iaData = await iaResp.json();

    setProgress(100);
    setStatus('✓ ' + total_recetas + ' recetas — abriendo app...', 'success');

    // Guardar el análisis en el backend para que la app lo lea
    const payload = { ...iaData, total_monto: montoTotal, periodo, farmacia_id: '930200835' };
    await fetch(BACKEND + '/debitos/guardar', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    // Abrir la app
    chrome.tabs.create({ url: 'https://reporte-ooss.netlify.app/?debitos=1#debitos' });

  } catch(e) {
    setStatus('Error: ' + e.message, 'error');
    btn.disabled = false;
    btn.textContent = 'Analizar débitos →';
    setProgress(0);
  }
}

document.addEventListener('DOMContentLoaded', function() {
  document.getElementById('btn-analizar').addEventListener('click', analizar);
  chrome.tabs.query({ active: true, currentWindow: true }, async ([tab]) => {
    if (!tab || !tab.url.includes('ncr.cofa.org.ar/tablero/resumen')) {
      document.getElementById('warning-url').style.display = 'block';
      document.getElementById('periodo-info').style.display = 'none';
      return;
    }
    try {
      const result = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => { const sel = document.querySelector('select'); return sel ? sel.value : null; }
      });
      const periodo = result[0].result;
      if (periodo) document.getElementById('periodo-texto').textContent = formatPeriodo(periodo);
    } catch(e) {}
  });
});
